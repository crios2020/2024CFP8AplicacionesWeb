<?php
ini_set('display_errors', 1);
$nro1=$_REQUEST['nro1'];
$nro2=$_REQUEST['nro2'];
$operacion=$_REQUEST['operacion'];
if(isset($nro1) && isset($nro2) && isset($operacion)){
    switch($operacion){
        case "suma":    echo ($nro1+$nro2);     break;
        case "resta":   echo ($nro1-$nro2);     break;
        case "multi":   echo ($nro1*$nro2);     break;
        case "divi":    
            if($nro2!=0){
                echo ($nro1/$nro2);  
            }else{
                echo "error / 0";
            }
        break;
    }
}
?>