<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>
    <h1>Hola Mundo PHP!</h1>

    <!--
        Extensión vscode    PHP v1.51.16099 DEVSENSE All-in-One PHP support

        http://localhost/aplicaciones/clase07/

        tutorialesprogramacionya

    -->

    <?php
        ini_set('display_errors', 1);

        //comentarios de una sola linea
        /* bloque de comentarios */

        $texto="Hola PHP!<br>";             //declaración de variable
        echo "<h1>Hola Mundo!!</h1>";       //sale por response
        echo $texto;

        //Parámetros de entrada
        //$_REQUEST[]       parámetros que ingresan por get y post
        //$_GET[]           parámetros que ingresan solo por get
        //$_POST[]          parámetros que ingresan solo por post

        //http://localhost/aplicaciones/clase07/?nombre=Carlos
        $nombre=$_GET['nombre'];
        if(isset($nombre)){
            echo "<h2>Hola ".$nombre."</h2>";
        }

    ?>

</body>
</html>