package ar.org.centro8.curso.java.services;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class TestService {
    
    //http://localhost:8080/api/v1
    @GetMapping("")
    public String getTest(){
        return "Servicio OK";
    }

    //http://localhost:8080/api/v1/test2
    @GetMapping("/test2")
    public String getTest2(){
        return "Servicio 2 OK";
    }

    //http://localhost:8080/api/v1/test3?nombre=Carlos
    @GetMapping("/test3")
    public String getTest3(
        @RequestParam(name="nombre", defaultValue = "") String nombre){
        return "Hola "+nombre;
    }

    //http://localhost:8080/api/v1/calculadora
    @GetMapping("/calculadora")
    public String getMethodName(
        @RequestParam(name="nro1", defaultValue = "0") double nro1,
        @RequestParam(name="nro2", defaultValue = "0") double nro2,
        @RequestParam(name="operacion", defaultValue = "0") String operacion
    ) {
        String resultado="0";
        switch (operacion) {
            case "suma":    resultado=(nro1+nro2)+"";       break;
            case "resta":   resultado=(nro1-nro2)+"";       break;
            case "multi":   resultado=(nro1*nro2)+"";       break;
            case "divi":    resultado=(nro1/nro2)+"";       break;
            default:        resultado=("error operación");  break;
        }
        return resultado;
    }
    


}
