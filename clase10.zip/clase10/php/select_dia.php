<?php
require_once "php/enums/dia.php";
foreach (Dia::cases() as $dia) {
    //echo $dia->name;
    echo "<option value='" . $dia->name . "' >" . $dia->name . "</option>";
}
