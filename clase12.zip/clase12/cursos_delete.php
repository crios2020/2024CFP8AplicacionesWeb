<?php ini_set("display_errors","1");?>
<?php
    require_once "php/connector/connector.php";
    //echo $_POST['idBorrar'];
    $connector=new Connector();
    $filtro="id=".$_POST['idBorrar'];
    $connector->delete("cursos",$filtro);
    header('Location: cursos.php');
?>