import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server{
    public static void main(String[] args) {
        //String mensaje="<h1>Servidor de Carlos</h1>";
        //mensaje=    "HTTP/1.1 200 OK\n"+
        //            "Content-Type: text/html\n"+
        //            "Content-Length: "+mensaje.length()+"\n\n"
        //            +mensaje;
        String mensaje=System.getProperties()+"\n"+System.getenv();
        mensaje=    "HTTP/1.1 200 OK\n"+
                    "Content-Type: text/plain\n"+
                    "Content-Length: "+mensaje.length()+"\n\n"
                    +mensaje;
        try (ServerSocket ss=new ServerSocket(8000)) {
            while (true) {
                System.out.println("Esperando conexión del cliente .....");
                try (
                    Socket so=ss.accept();
                    OutputStream out=so.getOutputStream();
                    ){
                    System.out.println("Se conecto: "+so.getInetAddress());
                    out.write(mensaje.getBytes());
                } catch (Exception ee) {
                    System.out.println(ee);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}