<?php
include_once "php/connector/connector.php";
$connector = new Connector();
$buscar='';
if(isset($_REQUEST['buscar'])) $buscar=$_REQUEST['buscar'];
$registros = $connector->get("cursos","titulo like '%".$buscar."%'");
foreach ($registros as $registro) {
    echo ("<tr>");
    echo ("<td>" . $registro['id'] . "</td>");
    echo ("<td>" . $registro['titulo'] . "</td>");
    echo ("<td>" . $registro['profesor'] . "</td>");
    echo ("<td>" . $registro['dia'] . "</td>");
    echo ("<td>" . $registro['turno'] . "</td>");
    echo ("</tr>");
}
?>
