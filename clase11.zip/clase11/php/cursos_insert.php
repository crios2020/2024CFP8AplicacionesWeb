<?php ini_set("display_errors","1");?>
<?php
    require_once "php/connector/connector.php";
    $connector =new Connector();

    if(
        isset($_REQUEST['titulo']) && $_REQUEST['titulo']!="" &&
        isset($_REQUEST['profesor']) && $_REQUEST['profesor']!=""
    ){
        $titulo=$_REQUEST['titulo'];
        $profesor=$_REQUEST['profesor'];
        $dia=$_REQUEST['dia'];
        $turno=$_REQUEST['turno'];
        //echo $titulo.' '.$profesor.' '.$dia.' '.$turno;

        $table="cursos";
        $campos="titulo,profesor,dia,turno";
        $values="'".$titulo."','".$profesor."','".$dia."','".$turno."'";
        $connector->insert($table,$campos,$values);
        echo "Se guardo un curso!";
    }else{
        echo 'Ingrese un nuevo curso!';
    }


?>