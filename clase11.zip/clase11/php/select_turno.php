<?php
require_once "php/enums/turno.php";
foreach (Turno::cases() as $turno) {
    echo "<option value='" . $turno->name . "' >" . $turno->name . "</option>";
}
