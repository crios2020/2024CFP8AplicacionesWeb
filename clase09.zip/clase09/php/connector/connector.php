<?php
class Connector{
    public function getConnection(): PDO{
        //Armado de url
        $driver='mysql';
        $hostname='localhost';
        $username='root';
        $password='';
        $base='colegio';
        return new PDO(
                        "$driver:host=$hostname;dbname=$base",
                        $username, 
                        $password
                    );
    }

    public function __construct(){} //constructor vacio

}
?>