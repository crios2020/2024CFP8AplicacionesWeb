<?php ini_set("display_errors","1");?>
<?php 
    //http://localhost/aplicaciones/clase09/php/test/test_connector.php
    echo '-- Test Connector --<br>';
    include_once "../connector/connector.php";

    try{
        $connector=new Connector();
        //$sql="select version()";
        $sql="select sqlite_version()";
        $registros=$connector->getConnection()->query($sql);
        foreach($registros as $row){
            echo $row[0].'<br>';
            echo 'Se conecto a la BD!<br>';
        }
    }catch(Exception $e){
        echo 'No se pudo connectar!<br>';
        echo $e;
    }

    echo '-- Fin Test --<br>';

    echo '-- Test get --<br>';
    $connector=new Connector();
    $registros=$connector->get(
            "alumnos",
            "apellido like '%z'");
    foreach($registros as $row){
        echo $row['id'].', '.$row['nombre'].', '.$row['apellido'].', '.
             $row['edad'].', '.$row['id_curso'].'<br>';
    }
    echo '-- Fin Test get';

    echo '-- Test getAll --<br>';
    $connector=new Connector();
    $registros=$connector->getAll("alumnos");
    foreach($registros as $row){
        echo $row['id'].', '.$row['nombre'].', '.$row['apellido'].', '.
             $row['edad'].', '.$row['id_curso'].'<br>';
    }
    echo '-- Fin Test get';
?>