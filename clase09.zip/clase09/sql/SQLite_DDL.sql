-- Active: 1729122205933@@127.0.0.1@3306

-- CTROL - ENTER para ejecutar una sentencia
-- CTROL - SHIFT - ENTER para ejecutar todo el script

drop table if exists alumnos;
drop table if exists cursos;

create table cursos(
    id int primary key,
    titulo varchar(25) not null,
    profesor varchar(25) not null,
    dia varchar(12) not null 
                check(dia IN('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES')),
    turno varchar(25) not null
                check(turno IN('MAÑANA','TARDE','NOCHE')),
    activo boolean default TRUE
);

create table alumnos(
    id int primary key,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    edad int not null check(edad >=18 and edad<=120),
    id_curso int null references cursos(id),
    activo boolean default TRUE
);